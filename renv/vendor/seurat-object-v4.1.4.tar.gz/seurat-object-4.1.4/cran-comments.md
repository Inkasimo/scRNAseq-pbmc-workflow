# SeuratObject v4.1.4

## Test environments
* local ubuntu 22.04 install, R 4.2.3
* win-builder (oldrelease, release, devel)

## R CMD check results

There were no ERRORs, WARNINGs, or NOTEs

## Downstream dependencies

There is one package that depends on SeuratObject: tidyseurat; this update does not impact its functionality

There are six packages that import SeuratObject: bbknnR, CAMML, scCustomize, scpoisson, Seurat, and Signac; this update does not impact their functionality

There are seven packages that suggest SeuratObject: cellpypes, RESET, scOntoMatch, SCpubr, singleCellHaystack, SPECK, and VAM; this update does not impact their functionality
