#' @details \code{show}: Display an object summary to stdout
#'
#' @return \code{show}: Invisibly returns \code{NULL}
