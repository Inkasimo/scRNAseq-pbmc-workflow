#' @details \code{Cells}: Get cell names
#'
#' @return \code{Cells}: A vector of cell names
